import java.util.Scanner;
import java.util.ArrayList;

class Contato {
    private String nome;
    private String telefone;

    public Contato(String nome, String telefone) {
        this.nome = nome;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }
}

public class projeto14 {
    public static void main(String[] args) {
        Scanner processamento = new Scanner(System.in);
        ArrayList<Contato> contatos = new ArrayList<>();
        int escolha = 0;

        while (escolha != 4) {
            System.out.println("===== MENU =====");
            System.out.println("1 - Adicionar contato");
            System.out.println("2 - Listar contatos");
            System.out.println("3 - Buscar contato");
            System.out.println("4 - Sair");
            System.out.print("Escolha: ");

            String entrada = processamento.nextLine();
            try {
                escolha = Integer.parseInt(entrada);
            } catch (NumberFormatException e) {
                System.out.println("");
                System.out.println("--------------------");
                System.out.println("Entrada inválida! Digite um número de 1 a 4.");
                System.out.println("--------------------");
                System.out.println("");
                continue;
            }

            switch (escolha) {
                case 1:
                    System.out.println("");
                    System.out.println("Você escolheu Adicionar Contato.");
                    System.out.println("");
                    System.out.print("Digite o Nome: ");
                    String nome = processamento.nextLine();
                    System.out.print("Digite o Telefone: ");
                    String telefone = processamento.nextLine();

                    contatos.add(new Contato(nome, telefone));
                    System.out.println("");
                    System.out.println("--------------------");
                    System.out.println("CONTATO SALVO COM SUCESSO!");
                    System.out.println("--------------------");
                    System.out.println("");

                    break;

                case 2:
                    System.out.println("");
                    System.out.println("Você escolheu Listar Contatos.");
                    System.out.println("");
                    if (contatos.isEmpty()) {
                        System.out.println("");
                        System.out.println("Nenhum contato cadastrado.");
                        System.out.println("");

                    } else {
                        int i = 1;
                        for (Contato listarcontatos : contatos) {
                            System.out.println("");
                            System.out.println("-------------------");
                            System.out.println("CONTATO " + i + ":");
                            System.out.println("NOME: " + listarcontatos.getNome());
                            System.out.println("TELEFONE: " + listarcontatos.getTelefone());
                            i++;
                        }
                        System.out.println("-------------------");
                        System.out.println("");

                    }
                    break;

                case 3:
                    System.out.println("");
                    System.out.println("Você escolheu Buscar Contato.");
                    System.out.println("");
                    System.out.print("Digite o nome ou telefone: ");
                    String busca = processamento.nextLine();
                    boolean encontrado = false;

                    for (Contato listarcontatos : contatos) {
                        if (listarcontatos.getNome().equalsIgnoreCase(busca)
                            || listarcontatos.getTelefone().equalsIgnoreCase(busca)) {
                            System.out.println("");
                            System.out.println("-------------------");
                            System.out.println("USUÁRIO ENCONTRADO!");
                            System.out.println("NOME: " + listarcontatos.getNome());
                            System.out.println("TELEFONE: " + listarcontatos.getTelefone());
                            System.out.println("-------------------");
                            System.out.println("");
                            encontrado = true;
                            break;
                        }
                    }

                    if (!encontrado) {
                        System.out.println("-------------------");
                        System.out.println("USUÁRIO NÃO ENCONTRADO.");
                        System.out.println("-------------------");
                    }
                    break;

                case 4:
                    System.out.println("");
                    System.out.println("Saindo do programa... Até mais! :)");
                    System.out.println("");
                    break;

                default:
                    System.out.println("Número inválido! Escolha entre 1 e 4.");
                    System.out.println("--------------------");
                    break;
            }
        }

        processamento.close();
    }
}
