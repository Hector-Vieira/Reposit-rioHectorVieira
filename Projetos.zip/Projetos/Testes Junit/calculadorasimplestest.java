import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class calculadorasimplestest{
    private final calculadorasimples calculadora = new calculadorasimples();
     @Test
     public void testSoma(){
        int a = 5;
        int b = 5;
        int resultado = calculadora.somar(a, b);
        assertEquals(10, resultado);
     }

     @Test
     public void testSubtracao(){
      int a = 6;
      int b = 4;
      int resultado = calculadora.subtrair(a, b);
      assertEquals(2, resultado);
     }

     @Test
     public void testmultiplicacao(){
      int a = 10;
      int b = 2;
      int resultado = calculadora.multiplicar(a, b);
      assertEquals(20, resultado);
     }

     @Test
     public void testmedia(){
      int a = 6;
      int b = 7;
      int c = 8;
      int resultado = calculadora.media(a, b, c);
      assertEquals(7, resultado);
     }
}
