public class calculadorasimples {
    public int somar (int a, int b){
        return a + b;
    }

    public int subtrair (int a, int b){
        return a - b;
    }

    public int multiplicar (int a, int b){
        return a * b;
    }

    public int media (int a, int b, int c){
        return (a + b + c) / 3;
    }
}